<?php
    require "connect.php";
    class Theloai{
        function Theloai($idTheLoai,$idKeyChuDe,$tenTheLoai,$hinhTheLoai){
            $this->idTheLoai = $idTheLoai;
            $this->idKeyChuDe = $idKeyChuDe;
            $this->TenTheLoai = $tenTheLoai;
            $this->HinhTheLoai = $hinhTheLoai;
        }
    }
    $arraytheloai = array();

    $idchude = $_POST['idchude'];
    //$idchude = "1";
    $query  = "SELECT * FROM theloai WHERE IdChuDe = '$idchude'";
    $data = mysqli_query($con,$query);
    while ($row = mysqli_fetch_assoc($data)){
        array_push($arraytheloai, new Theloai($row['IdTheLoai'],
                                                    $row['IdChuDe'],
                                                    $row['TenTheLoai'],$row['HinhTheLoai']));
    }
    echo json_encode($arraytheloai);
?>