<?php
require "connect.php";

    $query = "SELECT * FROM playlist";
    $data = mysqli_query($con,$query);
    class Danhsachplaylist{
        function Danhsachplaylist($idplaylist,$ten,$hinhnen,$hinhicon){
            $this->idPlayList = $idplaylist;
            $this->TenPlayList = $ten;
            $this->HinhPlayList = $hinhnen;
            $this->icon = $hinhicon;
        /*function Danhsachplaylist($idPlayList,$tenPlayList,$hinhPlayList,$icon){
            $this->idPlayList = $idPlayList;
            $this->TenPlayList = $tenPlayList;
            $this->HinhPlayList = $hinhPlayList;
            $this->icon = $icon;*/

        }
    }
    $arrayplaylist = array();
    while ($row = mysqli_fetch_assoc($data)){
        array_push($arrayplaylist, new Danhsachplaylist($row['IdPlayList'],$row['Ten'],
            $row['Hinhnen'],$row['Hinhicon']));
    }
    echo json_encode($arrayplaylist);

?>