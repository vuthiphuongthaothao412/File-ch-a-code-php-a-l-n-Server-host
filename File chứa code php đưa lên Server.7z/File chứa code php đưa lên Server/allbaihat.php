<?php
require "connect.php";
class Baihat{
    function Baihat($idBaiHat,$tenBaiHat,$hinhBaiHat,$casi,$linkBaiHat,$luotThich){
        $this->idBaiHat = $idBaiHat;
        $this->TenBaiHat = $tenBaiHat;
        $this->HinhBaiHat = $hinhBaiHat;
        $this->Casi = $casi;
        $this->LinkBaiHat = $linkBaiHat;
        $this->LuotThich = $luotThich;
    }
}
$arraybaihat = array();
$query = "SELECT * FROM baihat";
$data = mysqli_query($con,$query);
while ($row = mysqli_fetch_assoc($data)){
    array_push($arraybaihat, new Baihat($row['IdBaiHat'],$row['TenBaiHat'],$row['HinhBaiHat'],
        $row['Casi'],$row['LinkBaiHat'],$row['LuotThich']));
    }
    echo json_encode($arraybaihat);
?>