<?php
require "connect.php";
$query = "SELECT DISTINCT * FROM album ORDER BY rand(" . date("Ymd") .") LIMIT 4";
$dataalbum = mysqli_query($con,$query);
class Album{
    function Album($idAlbum,$tenAlbum,$tenCasi,$hinhAlbum){
        $this->idAlbum = $idAlbum;
        $this->TenAlbum = $tenAlbum;
        $this->TenCasi = $tenCasi;
        $this->HinhAlbum = $hinhAlbum;

    }
}
$arrayalbum = array();
while ($row = mysqli_fetch_assoc($dataalbum)){
    array_push($arrayalbum, new Album($row['IdAlbum'],
        $row['TenAlbum'],$row['TenCaSiAlbum'],$row['HinhAlbum']));
}
echo  json_encode($arrayalbum);
?>