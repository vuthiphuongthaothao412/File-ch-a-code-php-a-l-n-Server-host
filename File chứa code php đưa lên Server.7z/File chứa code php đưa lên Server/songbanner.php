<?php
    require "connect.php";//kết nối server
    //câu truy vấn database
    $query = "SELECT quangcao.Id,quangcao.Hinhanh,quangcao.Noidung,quangcao.IdBaiHat,baihat.TenBaiHat,baihat.HinhBaiHat 
                FROM `baihat` INNER JOIN quangcao ON quangcao.IdBaiHat = baihat.IdBaiHat 
                WHERE quangcao.IdBaiHat = baihat.IdBaiHat";
    $data = mysqli_query($con,$query);
    class Quangcao
    {
        //thêm dữ liệu bắt buộc
        function QuangCao($idQuangCao, $hinhAnh, $noiDung, $idBaiHat, $tenBaiHat, $hinhBaiHat)
        {
            $this->IdQuangCao = $idQuangCao;
            $this->HinhAnh = $hinhAnh;
            $this->NoiDung = $noiDung;
            $this->IdBaiHat = $idBaiHat;
            $this->TenBaiHat = $tenBaiHat;
            $this->HinhBaiHat = $hinhBaiHat;
        }
    }
    $mangquangcao = array();
    while ($row = mysqli_fetch_assoc($data)){
    array_push($mangquangcao, new Quangcao($row['Id'],
        $row['Hinhanh'],
        $row['Noidung'],
        $row['IdBaiHat'],
        $row['TenBaiHat'],
        $row['HinhBaiHat']));

    }
    echo json_encode($mangquangcao);

?>