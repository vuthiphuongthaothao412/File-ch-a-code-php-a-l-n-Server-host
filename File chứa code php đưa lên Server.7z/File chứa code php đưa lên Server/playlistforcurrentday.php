<?php
require"connect.php";
$query = "SELECT DISTINCT * FROM playlist ORDER BY rand(" . date("Ymd") . ") LIMIT 3";
class PlaylistToday{
    function PlaylistToday($idPlayList,$tenPlayList,$hinhPlayList,$icon){
        $this->idPlayList = $idPlayList;
        $this->TenPlayList = $tenPlayList;
        $this->HinhPlayList = $hinhPlayList;
        $this->icon = $icon;
    }
}
$arrayplaylistfortoday = array();
$data = mysqli_query($con,$query);
while ($row = mysqli_fetch_assoc($data)){
    array_push($arrayplaylistfortoday, new PlaylistToday($row['IdPlayList'],
        $row['Ten'],$row['Hinhnen'],$row['Hinhicon']));

}
echo json_encode($arrayplaylistfortoday);
?>