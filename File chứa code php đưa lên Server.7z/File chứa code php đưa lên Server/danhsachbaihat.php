<?php
require "connect.php";
class Baihat{
    function Baihat($idBaiHat,$tenBaiHat,$hinhBaiHat,$casi,$linkBaiHat,$luotThich){
        $this->idBaiHat = $idBaiHat;
        $this->TenBaiHat = $tenBaiHat;
        $this->HinhBaiHat = $hinhBaiHat;
        $this->Casi = $casi;
        $this->LinkBaiHat = $linkBaiHat;
        $this->LuotThich = $luotThich;
    }
}

$arraydanhsachbaihat = array();
if (isset($_POST['idalbum'])) {
    $idalbum = $_POST['idalbum'];
    $query = "SELECT * FROM baihat WHERE FIND_IN_SET('$idalbum',IdAlbum)";
     $data = mysqli_query($con,$query);
    while ($row = mysqli_fetch_assoc($data)){
        array_push($arraydanhsachbaihat, new Baihat($row['IdBaiHat'],$row['TenBaiHat'],$row['HinhBaiHat'],
            $row['Casi'],$row['LinkBaiHat'],$row['LuotThich']));
}
}
    
if (isset($_POST['idtheloai'])) {
    $idtheloai = $_POST['idtheloai'];
    //$idtheloai = $_POST['idplaylist'];
    $query = "SELECT * FROM baihat WHERE FIND_IN_SET('$idtheloai',IdTheLoai)";
     $data = mysqli_query($con,$query);
    while ($row = mysqli_fetch_assoc($data)){
        array_push($arraydanhsachbaihat, new Baihat($row['IdBaiHat'],$row['TenBaiHat'],$row['HinhBaiHat'],
            $row['Casi'],$row['LinkBaiHat'],$row['LuotThich']));
}
}
    

if (isset($_POST['idplaylist'])) {
    $idplaylist = $_POST['idplaylist'];
    
    $query = "SELECT * FROM baihat WHERE IdPlayList = '1'";
     $data = mysqli_query($con,$query);
    while ($row = mysqli_fetch_assoc($data)){
        array_push($arraydanhsachbaihat, new Baihat($row['IdBaiHat'],$row['TenBaiHat'],$row['HinhBaiHat'],
            $row['Casi'],$row['LinkBaiHat'],$row['LuotThich']));
        
}
}

if (isset($_POST['idquangcao'])) {
    $idquangcao = $_POST['idquangcao'];
    $queryquangcao = "SELECT * FROM quangcao WHERE Id = '$idquangcao'";
    $dataquangcao = mysqli_query($con, $queryquangcao);
    $rowquangcao = mysqli_fetch_assoc($dataquangcao);
    $id = $rowquangcao['IdBaiHat'];
    $query = "SELECT * FROM baihat WHERE IdBaiHat = '$id'";
     $data = mysqli_query($con,$query);
    while ($row = mysqli_fetch_assoc($data)){
        array_push($arraydanhsachbaihat, new Baihat($row['IdBaiHat'],$row['TenBaiHat'],$row['HinhBaiHat'],
            $row['Casi'],$row['LinkBaiHat'],$row['LuotThich']));
}
}


echo json_encode($arraydanhsachbaihat);
?>