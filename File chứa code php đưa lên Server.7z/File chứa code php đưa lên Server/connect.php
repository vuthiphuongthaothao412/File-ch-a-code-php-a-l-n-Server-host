<?php
//kết nối database trên server
$hostname = "localhost";//tên đăng nhập
$username = "id18052703_vuthao123"; //tài khoản đăng nhập
$password = "*eGxA_ik+9}H%b!F"; //mật khẩu
$databasename = "id18052703_androidappnhac";//database name muốn kết nốt

//câu truy vấn kết nối
$con = mysqli_connect($hostname,$username,$password,$databasename);
    //câu truy vấn trả về tiếng việt
    mysqli_query($con,"SET NAMES 'utf8'");
?>