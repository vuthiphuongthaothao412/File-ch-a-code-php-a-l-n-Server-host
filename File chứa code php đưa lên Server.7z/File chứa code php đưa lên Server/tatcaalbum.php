<?php
    require "connect.php";
    class Album{
        function Album($idAlbum,$tenAlbum,$tenCasi,$hinhAlbum){
            $this->idAlbum = $idAlbum;
            $this->TenAlbum = $tenAlbum;
            $this->TenCasi = $tenCasi;
            $this->HinhAlbum = $hinhAlbum;

        }
    }
    $arrayalbum = array();
    $query = "SELECT * FROM album";
    $data = mysqli_query($con,$query);
    while ($row = mysqli_fetch_assoc($data)){
        array_push($arrayalbum, new Album($row['IdAlbum'],
            $row['TenAlbum'],$row['TenCaSiAlbum'],$row['HinhAlbum']));
    }
    echo json_encode($arrayalbum);
?>