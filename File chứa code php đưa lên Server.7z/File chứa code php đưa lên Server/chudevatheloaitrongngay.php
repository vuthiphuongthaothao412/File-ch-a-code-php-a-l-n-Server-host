<?php
require "connect.php";

class TheLoai{
    function TheLoai($idTheLoai,$idKeyChuDe,$tenTheLoai,$hinhTheLoai){
        $this->idTheLoai = $idTheLoai;
        $this->idKeyChuDe = $idKeyChuDe;
        $this->TenTheLoai = $tenTheLoai;
        $this->HinhTheLoai = $hinhTheLoai;
    }
}
class ChuDe{
    function ChuDe($idChuDe,$tenChuDe,$hinhChuDe){
        $this->idChuDe = $idChuDe;
        $this->TenChuDe = $tenChuDe;
        $this->HinhChuDe = $hinhChuDe;

    }
}
$arraytheloai = array();
$arraychude = array();

$querytheloai = "SELECT DISTINCT * FROM theloai ORDER BY rand(". date("Ymd"). ") LIMIT 4";
$datatheloai = mysqli_query($con,$querytheloai);
while ($row = mysqli_fetch_assoc($datatheloai)){
    array_push($arraytheloai, new TheLoai($row['IdTheLoai'],
        $row['IdChuDe'],$row['TenTheLoai'],$row['HinhTheLoai']));
}

$querychude = "SELECT DISTINCT * FROM chude ORDER BY rand(". date("Ymd"). ") LIMIT 4";
$datachude = mysqli_query($con,$querychude);
while ($row = mysqli_fetch_assoc($datachude)){
    array_push($arraychude, new ChuDe($row['IdChuDe'],
        $row['TenChuDe'],$row['HinhChuDe']));
}
$arraychudetheloai = array('TheLoai' => $arraytheloai,'ChuDe'=>$arraychude);
echo json_encode($arraychudetheloai);
?>