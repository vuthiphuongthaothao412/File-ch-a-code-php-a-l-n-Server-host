<?php
    require "connect.php";
    class Baihat{
    function Baihat($idBaiHat,$tenBaiHat,$hinhBaiHat,$casi,$linkBaiHat,$luotThich){
        $this->idBaiHat = $idBaiHat;
        $this->TenBaiHat = $tenBaiHat;
        $this->HinhBaiHat = $hinhBaiHat;
        $this->Casi = $casi;
        $this->LinkBaiHat = $linkBaiHat;
        $this->LuotThich = $luotThich;
    }
}

    //$mangcakhuc =array();
    $mangbaihat =array();
    if(isset($_POST['tukhoa'])){
    $tukhoa = $_POST['tukhoa'];
    $query = "SELECT * FROM baihat WHERE lower (TenBaiHat) LIKE '%$tukhoa%'";
    $data = mysqli_query($con,$query);
        while ($row = mysqli_fetch_assoc($data)){
        /*array_push($mangcakhuc, new Baihat($row['IdBaiHat'],
            $row['TenBaiHat'],$row['HinhBaiHat'],$row['Casi'],$row['LinkBaiHat'],$row['LuotThich']));*/
            array_push($mangbaihat, new Baihat($row['IdBaiHat'],
            $row['TenBaiHat'],$row['HinhBaiHat'],$row['Casi'],$row['LinkBaiHat'],$row['LuotThich']));
        }
    }
    echo json_encode($mangbaihat);
    //echo json_encode($mangcakhuc);
    
?>